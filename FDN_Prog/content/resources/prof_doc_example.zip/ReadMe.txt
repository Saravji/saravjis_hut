This zip file includes 5 files:
Example_1.pdf
Example_2.pdf
Example_3.pdf
prof_doc_demo.docx
ReadMe.txt

Example_1, Example_2 and Example_3 are actual student documents from past versions of this course.
The content is not accurately reflecting what this version of the course is covering.
The names and identifiers have been blacked out to protect the student's privacy.

prof_doc_demo is the document created during the video.

ReadMe is this text file.